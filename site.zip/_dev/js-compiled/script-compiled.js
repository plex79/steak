'use strict';

(function ($, window, document, undefined) {

    'use strict';

    var app = app || {};
    console.log(app);

    app.ready = {
        init: function init() {
            app.initialize.init();
        }
    };

    $(document).ready(app.ready.init);

    app.initialize = {

        init: function init() {
            app.initialize.moja1();
            app.initialize.moja2();
        },

        moja1: function moja1() {
            console.log('ak 1');
        },

        moja2: function moja2() {
            console.log('ak 2');
        }

    };
})(jQuery, window, document);
//# sourceMappingURL=script-compiled.js.map
