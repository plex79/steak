(function($, window, document, undefined) {

    'use strict';

    var app = app || {};
    console.log(app);

    app.ready = {
        init: function () {
            app.initialize.init();
        }
    };

    $(document).ready(app.ready.init);

    app.initialize = {

        init: function () {
            app.initialize.moja1();
            app.initialize.moja2();
        },
        
        moja1: function(){
            console.log('ak 1');
        },

        moja2: function(){
            console.log('ak 2');
        }

    };


}(jQuery, window, document));

